---
title: "Additional resources"
---


See DataHaven's list of [trusted sources of information](https://ctdatahaven.org/articles/coronavirus-covid-19-connecticut-trusted-sources-information) on COVID-19.

The State of Connecticut has recently added [a variety of datasets on COVID-19](https://data.ct.gov/stories/s/COVID-19-data/wa3g-tfvc/) to its official open data portal.